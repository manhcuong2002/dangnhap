import React from "react";
import styles from "./Admin.module.scss";

const Admin = () => {
  return <div>Admin</div>;
};

export default Admin;
