import React from "react";

const orderHistory = () => {
  return <div>orderHistory</div>;
};

export default orderHistory;
